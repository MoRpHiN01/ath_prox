import 'package:flutter/material.dart';
import '../models/peer.dart';
import '../services/ble_service.dart';
import '../services/session_manager.dart';

class DeviceListScreen extends StatefulWidget {
  @override
  _DeviceListScreenState createState() => _DeviceListScreenState();
}

class _DeviceListScreenState extends State<DeviceListScreen> {
  final BleService _bleService = BleService();
  final SessionManager _sessionManager = SessionManager();
  List<Peer> _peers = [];
  bool _isAdvertising = false;

  @override
  void initState() {
    super.initState();
    _initDiscovery();
  }

  void _initDiscovery() async {
    _bleService.onPeerFound = (peer) {
      setState(() {
        final index = _peers.indexWhere((p) => p.instanceId == peer.instanceId);
        if (index >= 0) {
          _peers[index] = peer;
        } else {
          _peers.add(peer);
        }
      });
    };
    await _bleService.startScan();
  }

  void _toggleAdvertising() async {
    setState(() {
      _isAdvertising = !_isAdvertising;
    });
    if (_isAdvertising) {
      await _bleService.startAdvertising("I AM HERE", "available");
    } else {
      await _bleService.stopAdvertising();
    }
  }

  void _handleSessionToggle(Peer peer) {
    final isInSession = _sessionManager.isInSessionWith(peer.instanceId);
    if (isInSession) {
      _sessionManager.endSession(peer.instanceId);
    } else {
      _sessionManager.startSession(peer);
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("ATH PROXIMITY"),
        actions: [
          IconButton(
            icon: Icon(_isAdvertising ? Icons.stop : Icons.play_arrow),
            onPressed: _toggleAdvertising,
          ),
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: _initDiscovery,
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: _peers.length,
        itemBuilder: (context, index) {
          final peer = _peers[index];
          final inSession = _sessionManager.isInSessionWith(peer.instanceId);
          return ListTile(
            title: Text(peer.displayName),
            subtitle: Text("Status: ${peer.status}"),
            trailing: ElevatedButton(
              onPressed: () => _handleSessionToggle(peer),
              child: Text(inSession ? "End Session" : "Invite"),
            ),
          );
        },
      ),
    );
  }
}