import 'package:flutter/material.dart';

class DevelopmentCompanyScreen extends StatelessWidget {
  const DevelopmentCompanyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Development Company")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Company Name: ATH Solutions", style: TextStyle(fontSize: 18)),
            const SizedBox(height: 10),
            Row(
              children: [
                const Text("Website: ", style: TextStyle(fontSize: 18)),
                InkWell(
                  onTap: () {
                    // launch company website
                  },
                  child: const Text("https://www.athsolutions.co.za",
                    style: TextStyle(fontSize: 18, color: Colors.blue, decoration: TextDecoration.underline),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            const Text("Contact Email: support@athsolutions.co.za", style: TextStyle(fontSize: 18)),
            const SizedBox(height: 10),
            const Text("Phone: +27 39 315 2222", style: TextStyle(fontSize: 18)),
            const SizedBox(height: 10),
            const Text("Address: 37 Old Saint Faiths Road, Umtentweni, Port Shepstone, 4235", style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
    );
  }
}
