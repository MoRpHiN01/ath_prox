import 'package:flutter/material.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final TextEditingController _displayNameController = TextEditingController();
  final TextEditingController _actualNameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  String _status = "Available";

  @override
  void initState() {
    super.initState();
    // Load from storage or set defaults
    _displayNameController.text = "Your Display Name";
    _actualNameController.text = "Your Full Name";
    _emailController.text = "you@example.com";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('User Profile')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _displayNameController,
              decoration: const InputDecoration(labelText: 'Display Name'),
            ),
            TextField(
              controller: _actualNameController,
              decoration: const InputDecoration(labelText: 'Actual Name'),
            ),
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(labelText: 'Email Address'),
            ),
            DropdownButtonFormField<String>(
              value: _status,
              decoration: const InputDecoration(labelText: 'Status'),
              items: ['Available', 'Busy', 'Do Not Disturb']
                  .map((status) => DropdownMenuItem(
                        value: status,
                        child: Text(status),
                      ))
                  .toList(),
              onChanged: (value) {
                if (value != null) {
                  setState(() {
                    _status = value;
                  });
                }
              },
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Save profile info locally here
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Profile saved")));
              },
              child: const Text('Save Profile'),
            ),
          ],
        ),
      ),
    );
  }
}