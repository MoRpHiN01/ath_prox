
import 'package:flutter/material.dart';
import '../models/peer.dart';
import '../services/ble_service.dart';

class BlePeerListScreen extends StatefulWidget {
  final BleService bleService;

  const BlePeerListScreen({Key? key, required this.bleService}) : super(key: key);

  @override
  _BlePeerListScreenState createState() => _BlePeerListScreenState();
}

class _BlePeerListScreenState extends State<BlePeerListScreen> {
  List<Peer> peers = [];
  bool isAdvertising = false;
  bool isScanning = false;

  @override
  void initState() {
    super.initState();
    _startScan();
  }

  void _startScan() async {
    setState(() => isScanning = true);
    await widget.bleService.startScan(onPeerFound: (peer) {
      setState(() {
        if (!peers.any((p) => p.instanceId == peer.instanceId)) {
          peers.add(peer);
        }
      });
    }, onError: (e) {
      debugPrint('Scan error: \$e');
    });
    setState(() => isScanning = false);
  }

  void _toggleAdvertising() async {
    if (isAdvertising) {
      await widget.bleService.stopAdvertising();
    } else {
      await widget.bleService.startAdvertising('User', 'available');
    }
    setState(() => isAdvertising = !isAdvertising);
  }

  void _handleInvite(Peer peer) {
    widget.bleService.sendInvite(peer.instanceId);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Invite sent to \${peer.displayName}")));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Nearby Devices'),
        actions: [
          IconButton(
            icon: Icon(isAdvertising ? Icons.stop_circle : Icons.campaign),
            onPressed: _toggleAdvertising,
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _startScan,
          )
        ],
      ),
      body: isScanning
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              itemCount: peers.length,
              itemBuilder: (context, index) {
                final peer = peers[index];
                return ListTile(
                  title: Text(peer.displayName),
                  subtitle: Text("Status: \${peer.status}"),
                  trailing: ElevatedButton(
                    onPressed: () => _handleInvite(peer),
                    child: const Text('Invite'),
                  ),
                );
              },
            ),
    );
  }
}
