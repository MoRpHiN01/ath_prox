
import 'package:flutter/material.dart';
import 'screens/device_list_screen.dart';
import 'widgets/navigation_drawer.dart';

void main() {
  runApp(const ProximityApp());
}

class ProximityApp extends StatelessWidget {
  const ProximityApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ATH PROXIMITY - GET CONNECTED',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.teal,
      ),
      home: const DeviceListScreen(),
    );
  }
}
