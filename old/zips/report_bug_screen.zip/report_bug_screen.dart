
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class ReportBugScreen extends StatelessWidget {
  const ReportBugScreen({Key? key}) : super(key: key);

  void _launchEmailClient() async {
    final Uri emailLaunchUri = Uri(
      scheme: 'mailto',
      path: 'bugs@getconnected.co.za',
      query: Uri.encodeFull('subject=Bug Report - ATH PROXIMITY&body=Describe the bug here...'),
    );

    if (await canLaunchUrl(emailLaunchUri)) {
      await launchUrl(emailLaunchUri);
    } else {
      // Handle the case where the email app cannot be opened
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Report a Bug'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Found a bug?',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            const Text(
              'Click the button below to send us an email with details about the issue you encountered.',
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              icon: const Icon(Icons.bug_report),
              label: const Text('Report Bug'),
              onPressed: _launchEmailClient,
            ),
          ],
        ),
      ),
    );
  }
}
