import 'peer.dart';

class Session {
  final Peer peer;
  final DateTime startTime;
  DateTime? endTime;

  Session({required this.peer, required this.startTime, this.endTime});
}