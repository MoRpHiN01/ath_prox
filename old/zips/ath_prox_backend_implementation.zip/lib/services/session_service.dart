import 'dart:collection';
import '../models/peer.dart';
import '../models/session.dart';

class SessionService {
  final Map<String, Session> _activeSessions = HashMap();

  void startSession(Peer peer) {
    final session = Session(peer: peer, startTime: DateTime.now());
    _activeSessions[peer.instanceId] = session;
  }

  void endSession(String instanceId) {
    if (_activeSessions.containsKey(instanceId)) {
      _activeSessions[instanceId]?.endTime = DateTime.now();
    }
  }

  Duration? getSessionDuration(String instanceId) {
    final session = _activeSessions[instanceId];
    if (session?.endTime != null) {
      return session!.endTime!.difference(session.startTime);
    }
    return null;
  }

  List<Session> getAllSessions() {
    return _activeSessions.values.toList();
  }
}