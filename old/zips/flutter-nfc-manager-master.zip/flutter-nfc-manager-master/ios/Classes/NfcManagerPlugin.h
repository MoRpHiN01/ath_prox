#import <Flutter/Flutter.h>

@interface NfcManagerPlugin : NSObject<FlutterPlugin>
@end
