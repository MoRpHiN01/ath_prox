# nfc_manager_example

Demonstrates how to use the nfc_manager plugin.
