import 'package:flutter/services.dart';

const MethodChannel channel = MethodChannel('plugins.flutter.io/nfc_manager');
